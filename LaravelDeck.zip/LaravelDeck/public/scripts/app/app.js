var app = angular.module('DeckApp', [
        'ui.router'
    ]
);